# FitPulse Pro — GitHub Pages PWA

This is a Vite + React project created from the supplied FitPulse Pro React source. It preserves the existing workout tracker UI and adds a real static web app manifest, a build-generated same-origin service worker, GitHub Pages deployment, and safer IndexedDB recovery.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Deploy to GitHub Pages

1. Create a new GitHub repository, for example `fitpulse-pro`.
2. Upload the contents of this folder to the repository root (not the ZIP itself).
3. Commit to the `main` branch.
4. Open **Settings → Pages** and choose **GitHub Actions** as the build/deployment source.
5. The workflow in `.github/workflows/deploy.yml` builds the app and deploys `dist/`.
6. Wait for the Actions workflow to finish, then open the published Pages URL in Chrome over HTTPS.

The Vite build uses relative asset paths (`base: './'`) so it works on a GitHub project Pages URL such as `https://USERNAME.github.io/fitpulse-pro/`.

## PWA verification

- Manifest: `manifest.webmanifest` is generated from `vite.config.js` and linked in `index.html`.
- Icons: static 192×192 and 512×512 PNG files are in `public/icons/`.
- Service worker: `vite-plugin-pwa` generates `dist/sw.js` and precaches the built app shell and static assets.
- Offline: first open the site online and wait for the service worker to activate; then test airplane mode / DevTools offline.
- Android: open the HTTPS Pages URL in Chrome → ⋮ → Install app (or Add to Home screen if Chrome offers that option).
- Persistence: workout state is stored in LocalStorage and mirrored to IndexedDB. On startup, IndexedDB is used to recover state if LocalStorage is missing or invalid.

## Important data migration note

Browser storage belongs to an origin. Data saved while using the Gemini preview or Google Sites does not automatically move to the GitHub Pages origin. Before switching, use FitPulse Pro's **Settings → Export JSON Backup** on the old site. After deployment, open the new site and use **Settings → Restore from Backup**.

## Limitations

A production deployment and physical Android installation test require access to the user's GitHub account and Android device. This source bundle can be built and checked locally, but those device/account actions are not performed by creating this ZIP.
